#!/usr/bin/perl

$_ = "Weeeee";

if (/(e{1,})/) {
	print "$1\n";
}

#!/usr/bin/perl

	$format = 7;
	printf "%${format}d\n", 100;

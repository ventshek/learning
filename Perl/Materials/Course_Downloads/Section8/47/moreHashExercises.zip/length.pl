#!/usr/bin/perl

use strict;

my $string = "string length";
my $length = length "$string";

print "the length of the string is: $length\n";
